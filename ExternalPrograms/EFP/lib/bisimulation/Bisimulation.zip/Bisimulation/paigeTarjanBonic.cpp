//------------------------------------------------------------------------------
//Title:       Bisimulation
//Version:     9.1
//Author:      Ugel Nadia
//Company:     University of Udine
//Description: this file contains the Paige, Tajan and Bonic Algorithm
//------------------------------------------------------------------------------
#include "fastBisimulation.h"
#include <iostream>//debug


indexType maxLabel;
indexType blockLabel[MAXINDEX];//represents the new labels
indexType f[MAXINDEX];  //maintains for each node the unique successor
indexType sGc; //starting pointer to the subgraph (only cycles)
indexType next[MAXINDEX], prev[MAXINDEX]; /*structures representing the cyclic
          part of the subgraph*/
indexType minSet[MAXINDEX],mS;//structures that represent the acyclic part
indexType numPred[MAXINDEX];  //to compute the number of predecessors
                         //it is used also as storage storage (list of pi)
indexType buffer[MAXINDEX],b; //maintains all the cycles "string"
indexType pi[MAXINDEX]; // to compute SRP LLR and
                    //it used also as storage storage (pointers to the nodes)
indexType storage;
indexType toLabel;/*starting pointer of toLabel
                (the array minSet is used as the list)*/
indexType maxLength;
indexType list[MAXINDEX];
indexType newTreeLabels[MAXINDEX];
indexType S;

struct bucketItem{
  indexType pBuffer;
  indexType length;
  indexType firstNode;
  struct bucketItem *next;
};
struct bucketItem *bucket[MAXINDEX], *bucketList;
struct bucketItem *lastInBucket[MAXINDEX];

//extern variables from bisimulation
  extern indexType freeQBlock,QBlockLimit;
  extern indexType freeXBlock;
  extern indexType rankPartition;
  extern indexType splitD[MAXINDEX];

/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/*compute the small repeated prefix: start is the beginning  of the "string"
in buffer; length is its length; it returns the length of the SRP and length if
there is no SRP*/
indexType SmallRepeatedPrefix(indexType start, indexType length)
{
  indexType k,q,l,last;

  pi[start] = 0;
  k = start;
  for (q=start+1;q<start+length;q++){
    while (k>start && buffer[k]!=buffer[q])
      k = pi[k-1];
    if (buffer[k]==buffer[q])
      k++;
    pi[q] = k - start;
  }
  l = length-pi[start+length-1];
  last = pi[start+length-1];
  //it is the initialisation for storage (pi will be used as the storage list)
  for (q=start;q<start+length;q++)
    pi[q] = NIL;
  if (last>=(length+1)/2)
    if ((length%l)==0)
      return l;
  return length;
}

/*compute the lexicographically least rotation: start is the beginning  of
the "string" in buffer; length is its length; it returns the index of the first
"character" of the llr*/
indexType LexLeastRotation(indexType start, indexType length)
{
  indexType k,q,i,j;

  k = start;
  q = start + 1;
  while (q<start+length){
    if (buffer[k]<buffer[q]){
      q++;
      continue;
    }
    if (buffer[k]>buffer[q]){
      k = q++;
      continue;
    }
    i = k;
    j = q;
    while (buffer[i]==buffer[j]){
      i = (i+1)%(length+start)+start;
      j = (j+1)%(length+start)+start;
      if (i==k)
        return k;
    }
    if (buffer[i]<=buffer[j]){
      if (j<q)
        return k;
      q = j;
      continue;
    }
    if (buffer[i]>buffer[j]){
      k = q;
      if (j<q)
        return k;
      q = j;
      continue;
    }
  }
  return k;
}

/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/*it recognise the cycle part of the subgraph,
using numPred and minSet as specified in the article of PTB*/
void CycleVertices()
{
  indexType fmS;

  while (mS!=NIL){
    (numPred[f[mS]])--;
    if (numPred[f[mS]]==0){
      fmS = f[mS];
      //this vertex has to move from the cycle part(sGc) of the subgraph to mS
      if (prev[fmS]!=NIL)
        next[prev[fmS]] = next[fmS];
      else
        sGc = next[fmS];
      if (next[fmS]!=NIL)
        prev[next[fmS]] = prev[fmS];
      //add fmS to minSet removing mS
      minSet[fmS] = minSet[mS];
      mS = fmS;
    } else
      mS = minSet[mS];
  }
}

/*it analyse all the cycles found in the previous cycleVertices() call;
it first calculate LLR(SRP(cycle)) and then create a bucketItem for each cycle
The bucketItem is a data structure that stores information about the labelling
of the cycle that is stored in buffer. This structure is then used to
radix-order all the LLR(SRP(cycle)).*/
void AnalyseCycles()
{
  indexType i,k,x,y,newRepresentative;
  struct bucketItem *bI;

  /*before the while:cyclic vertices have numPred=1 (as from cycleVertices())
  after the while: first node in the cycles has numPred=3; other nodes in
  cycles have numPred=2; all the others (tree nodes) have numPred=0.*/
  b = 0;
  bucketList = NULL;
  maxLength = 0;

  x = sGc;
  while (x!=NIL){
    //cycle vertex already analised
    if (numPred[x]!=1){
      x = next[x];
      continue;
    }
    //scan the cycle through f and mark the vertex belonging to this cycle;
    //create the bucketItem structure
    numPred[x] = 3;
    bI = new struct bucketItem;
    bI->pBuffer = b;  //the cycle representation in buffer starts from b
    bI->firstNode = x;  //is the representative node of the cycle
    buffer[b++] = blockLabel[G[x].block];
    y = f[x];
    while (y!=x){
      numPred[y] = 2;
      buffer[b++] = blockLabel[G[y].block];
      y = f[y];
    }
    //buffer[bI->pBuffer..b-1] contains the cycle starting from x
    bI->length = b - bI->pBuffer;
    //calculate the SRP of the cycle;
    /*the significant part of the cycle is just the SRP: hence we
    do not consider the remaining part (length is updated)*/
    bI->length = SmallRepeatedPrefix(bI->pBuffer,bI->length);
    b = bI->pBuffer + bI->length;
    //calculate the LLR of the cycle
    k = LexLeastRotation(bI->pBuffer,bI->length);
    //find the max length of all the LLR
    if (maxLength<bI->length)
      maxLength = bI->length;
    /*buffer[k .. (b-1)] * buffer[bI->pBuffer .. k-1]
    stores the LLR of the cycle. Hence we need to re-arrange it
    re-arrange also the representative!!*/
      //watch out the end of the buffer
      //should be:inv(all);inv(first part);inv(second part)
    newRepresentative = bI->firstNode; //it's x!
    numPred[newRepresentative] = 2;
    for (i=bI->pBuffer;i<k;i++){
      newRepresentative = f[newRepresentative];
      buffer[i+bI->length] = buffer[i];
    }
    bI->firstNode = newRepresentative;
    numPred[newRepresentative] = 3;
    k = k - bI->pBuffer;
    for (i=bI->pBuffer;i<b;i++)
      buffer[i] = buffer [i+k];
    //buffer[bI->pBuffer .. b-1] stores the LLR(SRP(cycle))
    //insert the cycle in the bucketList
    bI->next = bucketList;
    bucketList = bI;
    x = next[x];
  }
}

/*it sorts the cycles using radix sort that uses bucket sort as
stable sub-sort*/
void OrderCycles()
{
  indexType i,j,k;
  struct bucketItem *next,*shortCycles;
  /*character is the label of the nodes being analysed and respect which
  we have to sort*/
  indexType character;

  //if no cycle or just one then return
  if (bucketList==NULL || bucketList->next==NULL)
    return;

  for (i=maxLength;i>0;i--){
    shortCycles = NULL;
    while (bucketList!=NULL){
      next = bucketList->next;
      if (i==bucketList->length){
      //insert the cycle on the top of the bucket
        /*since i == bucketList->length then this is the first time this cycle
        is analysed and is before in order respect to all the other cycles*/
        character = buffer[bucketList->pBuffer+i-1];
        bucketList->next = bucket[character];
        bucket[character] = bucketList;
        if (lastInBucket[character]==NULL)
          lastInBucket[character] = bucketList;
      } else if (i<bucketList->length){
      //insert the cycle on the bottom of the bucket to have a stable bucketsort
        character = buffer[bucketList->pBuffer+i-1];
        if (lastInBucket[character]!=NULL)
          (lastInBucket[character])->next = bucketList;
        else
          bucket[character] = bucketList;
        bucketList->next = NULL;
        lastInBucket[character] = bucketList;
      }else{
      //otherwise this cycle is not long enough to be inserted in the buckets
        bucketList->next = shortCycles;
        shortCycles = bucketList;
      }
      bucketList = next;
    }
    //merging the buckets
    //find the first bucket not empty
    for(j=0;bucket[j]==NULL;j++)
      ;
    bucketList = bucket[j];
    bucket[j] = NULL;
    k = j++;
    /*since we have renamed the label, we know that there are at most maxLabel
    different labels that have range from 0 to maxLabel-1*/
    for (;j<maxLabel;j++)
      if (bucket[j]!=NULL){
        (lastInBucket[k])->next = bucket[j];
        lastInBucket[k] = NULL;
        bucket[j] = NULL;
        k = j;
      }
    (lastInBucket[k])->next = shortCycles;
    lastInBucket[k] = NULL;
  }
}

/*if we have some cycles that have the same LLR(SRP) then we have that
there are multiple occurrence of the same "string" in the buffer.
We want only one! So the Q-Label we will assign will be the index in buffer.
We have also that buffer represents QtoB since buffer[i]=j means that to the
QLabel i corresponds BLabel j.
At the same time we compute the toLabel set(using minSet) as in the
article of PTB.
Moreover we assign to each node x a pointer to correspondent  cycle (represented
by a bucketItem and store in bucket[x]) and the shift from the representative
node (stored in G[x].rank).*/
void AssignCycleLabels()
{
  struct bucketItem *bL, *next;
  struct adjList_1 *adj_1;
  indexType i,x,y;

  toLabel = NIL;
  if (bucketList==NULL)
    return;
  bL = bucketList;
  //assign pointer and shift to the first bucket
  i = 0;  //represents the shift from the "first" node in the cycle
  x = bL->firstNode;
  bucket[x] = bL;
  G[x].rank = (i++) % bL->length;
  //compute toLabel
  adj_1 = G[x].adj_1;
  while (adj_1!=NULL){
    if (numPred[adj_1->node]==0){
      //add to toLabel
      minSet[adj_1->node] = toLabel;
      toLabel = adj_1->node;
      }
    adj_1 = adj_1->next;
  }
  y = f[x];
  while (x!=y){
    bucket[y] = bL;
    G[y].rank = (i++) % bL->length;
    adj_1 = G[y].adj_1;
    //compute toLabel
    while (adj_1!=NULL){
      if (numPred[adj_1->node]==0){
        //add to toLabel
        minSet[adj_1->node] = toLabel;
        toLabel = adj_1->node;
        }
      adj_1 = adj_1->next;
    }
    y = f[y];
  }

  next = bL->next;
  while (next!=NULL){
    i = 0;
    x = next->firstNode;
    bucket[x] = next;
    G[x].rank = (i++) % next->length;
    //compute toLabel
    adj_1 = G[x].adj_1;
    while (adj_1!=NULL){
      if (numPred[adj_1->node]==0){
        //add to toLabel
        minSet[adj_1->node] = toLabel;
        toLabel = adj_1->node;
        }
      adj_1 = adj_1->next;
    }
    y = f[x];
    while (x!=y){
      bucket[y] = next;
      G[y].rank = (i++) % next->length;
      adj_1 = G[y].adj_1;
      //compute toLabel
      while (adj_1!=NULL){
        if (numPred[adj_1->node]==0){
          //add to toLabel
          minSet[adj_1->node] = toLabel;
          toLabel = adj_1->node;
          }
        adj_1 = adj_1->next;
      }
      y = f[y];
    }
    //the two LLR(SRP) have not the same length
    if (bL->length!=next->length){
      bL = next;
      next = next->next;
      continue;
    }
    //check if the two LLR(SRP) are equal
    for (i=0;i<bL->length;i++)
      if (buffer[bL->pBuffer+i]!=buffer[next->pBuffer+i])
        break;
    if (i==bL->length)
      next->pBuffer = bL->pBuffer;
    bL = next;
    next = next->next;
  }
}

/*it computes the initial segment of the trees that will have the cycle QLabels.
At the same time we compute storage that is a set containing the final segment
and will be used in stage2().*/
void Stage1()
{
  indexType x,fx,LBx,LQfx,Qpred,QtoB;
  struct bucketItem *bucketfx;
  struct adjList_1 *adj_1;

  storage = NIL;
  while (toLabel!=NIL){
    //pop x from toLabel
    x = toLabel;
    toLabel = minSet[toLabel];
    //calculate if x has really the same QLabel of the cycle
    fx = f[x];
    bucketfx = bucket[fx];
    LBx = blockLabel[G[x].block];
    LQfx = bucketfx->pBuffer + G[fx].rank;
    if (G[fx].rank==0)
      Qpred = bucketfx->pBuffer + bucketfx->length -1;
    else
      Qpred = LQfx -1;
    QtoB = buffer[Qpred];
    if (LBx==QtoB){
      //assign the label Qpred to x
      bucket[x] = bucketfx;
      G[x].rank = Qpred - bucketfx->pBuffer;
      //add all the predecessor of x in toLabel
      adj_1 = G[x].adj_1;
      while (adj_1!=NULL){
        minSet[adj_1->node] = toLabel;
        toLabel = adj_1->node;
        adj_1 = adj_1->next;
      }
    }else{
      //x is not a node with the QLabel of the cycles: add it in storage
      if (pi[LQfx]==NIL){
        numPred[LQfx] = storage;
        storage = LQfx;
      }
      list[x] = pi[LQfx];
      pi[LQfx] = x;
    }
  }
}

/*it computes the final segment of the trees that will not have the
cycle QLabels.
Remainder: newTreeLabels[] has been cleared in multipleNodes() (all the indexes
corresponding to BLabels point to NIL)*/
/*after stage2() the nodes x of the subgraph are associated to a QLabel
that we can identify by  ( bucket[x]->pBuffer + G[x].rank )*/
void Stage2()
{
  indexType x,y,actualLabelRange,xBLabel,LQfy;
  struct bucketItem *bI;
  struct adjList_1 *adj_1;

  //fake bucketItem for the final segment
  bI = new struct bucketItem;
  bI->pBuffer = maxLabel;
  bI->next = bucketList;
  bucketList = bI;

  while (storage!=NIL){
    /*for each "block" of elements of storage with successor with the
    same QLabel, make a partition according to the BLabel of the elements*/
    x = pi[storage];
      //to re-use pi to assign proper block from QLabels
    pi[storage] = NIL;
    storage = numPred[storage];
    actualLabelRange = maxLabel;
    while (x!=NIL){
      xBLabel = blockLabel[G[x].block];
      /*if newTreeLabels[] is less than actualLabelRange, it means whether
      that is NIL (untouched) and we can use it or that it has been used
      in a precedent "while (storage!=NIL)" step and we can overwrite it.*/
      if (newTreeLabels[xBLabel]<actualLabelRange){
        //assign a new label
        bucket[x] = bI;
        G[x].rank = maxLabel - bI->pBuffer;
        pi[maxLabel] = NIL;
        newTreeLabels[xBLabel] = maxLabel++;
      }else{
        bucket[x] = bI;
        G[x].rank = newTreeLabels[xBLabel]-bI->pBuffer;
      }
      //add x-predecessors to storage
      adj_1 = G[x].adj_1;
      while (adj_1!=NULL){
        y = adj_1->node;
        //remember that f(y)=x and that bucket[x]=bI
        LQfy = bI->pBuffer + G[x].rank;
        if (pi[LQfy]==NIL){
          numPred[LQfy] = storage;
          storage = LQfy;
        }
        list[y] = pi[LQfy];
        pi[LQfy] = y;
        adj_1 = adj_1->next;
      }
      x = list[x];
    }
  }
}

/*labelling the tree nodes there is a initial segment that will have the
same QLabels of the cycle nodes and a final segment that will have different
QLabels. There are two different stages to compute them.*/
void AssignTreeLabels()
{
  Stage1();
  Stage2();
}

/*here the nodes x of the subgraph are associated to a QLabel that we can
identify by ( bucket[x]->pBuffer + G[x].rank ). We have to create proper
blocks for each one of the QLabel. Then we have to set the rankPartition
list so we can carry on with the splits in the main procedure of FBA.
We scan all the nodes using G[].nIB, G[].pIB and Q[].nB, Q[]pB.*/
void Rearrange()
{
  indexType i,B,S1,D,next,nextB,QLabel,newD;

  B = X[S].firstBlock;
  rankPartition = NIL;
  //free S space
  X[S].nextXBlock = freeXBlock;
  X[S].prevXBlock = NIL;
  X[S].firstBlock = NIL;
  freeXBlock = S;
  while (B!=NIL){ //for each block
    i = Q[B].firstNode;
    nextB = Q[B].nextBlock;
    Q[B].firstNode = NIL;
    Q[B].nextBlock = NIL;
    Q[B].prevBlock = NIL;
    Q[B].size = 0;
    while (i!=NIL){ //for each node in block
      next = G[i].nextInBlock;
      QLabel = bucket[i]->pBuffer + G[i].rank;
      if (pi[QLabel]==NIL){
        //create a new block D
        if (freeQBlock==NIL){ //check for free space in memory
          if(QBlockLimit==MAXINDEX){
            std::cout << "MEMORY LIMIT!!!!!!!!!";
            std::cin >> i;
            exit(-1);
          }
          freeQBlock = QBlockLimit++;
          Q[freeQBlock].size = 0;
          Q[freeQBlock].nextBlock = NIL;
          splitD[freeQBlock]=numberOfNodes;
          //not necessary to initialise
          //Q[freeQBlock].prevBlock = NIL;
          //Q[freeQBlock].superBlock = NIL;
          //Q[freeQBlock].firstNode = NIL;
        }
        pi[QLabel] = freeQBlock;
        newD = freeQBlock; //index of D1 (new block of x)
        freeQBlock = Q[freeQBlock].nextBlock;
        //insert D1 in rankPartition creating a new Xblock with only one B block
        S1 = freeXBlock;
        freeXBlock = X[freeXBlock].nextXBlock;
        if (rankPartition!=NIL)
          X[rankPartition].prevXBlock = S1;
        X[S1].nextXBlock = rankPartition;
        rankPartition = S1;
        //X[S1].prevXBlock = NIL;
        X[S1].firstBlock = newD;
        Q[newD].prevBlock = NIL;
        Q[newD].nextBlock = NIL;
        //insert i in the new block
        Q[newD].firstNode = i;
        Q[newD].size = 1;
        G[i].nextInBlock = NIL;
        G[i].prevInBlock = NIL;
        G[i].block = newD;
      } else{
        D = pi[QLabel];
        G[Q[D].firstNode].prevInBlock = i;
        G[i].nextInBlock = Q[D].firstNode;
        G[i].prevInBlock = NIL;
        G[i].block = D;
        Q[D].firstNode = i;
        (Q[D].size)++;
      }
      i = next;
    }
    //free B space
    Q[B].nextBlock = freeQBlock;
    freeQBlock = B;
    B = nextB;
  }
}

/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

void PaigeTarjanBonic()
{
  CycleVertices();
  AnalyseCycles();
  OrderCycles();
  AssignCycleLabels();
  AssignTreeLabels();
  Rearrange();
}

/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/

/*function that find out if the sub-graph being analysed has or not
multiple nodes; if not simply returns false; otherwise it returns true */
bool MultipleNodes(indexType s)
{
  indexType i,B;
  adjList_1 *adj_1;

  /*before analysing a certain rank, there is only one XBlock containing the
  nodes having that particular rank (obviously there can be more than one
  QBlock)*/

  //NB: it is sure that S is not NIL
  S = s;

  //initialisation
  maxLabel = 0;
  B = X[S].firstBlock;
  while (B!=NIL){ //for each block
    //clearing for successive steps
    bucket[maxLabel] = NULL;
    newTreeLabels[maxLabel] = NIL;
    //associate a label to each block
    blockLabel[B] = maxLabel++;
    i = Q[B].firstNode;
    while (i!=NIL){ //for each node in block
      f[i] = NIL;
      i = G[i].nextInBlock;
    }
    B = Q[B].nextBlock;
  }

  sGc = NIL; //only cycles
  mS = NIL;

  B = X[S].firstBlock;
  while (B!=NIL){
    i = Q[B].firstNode;
    while (i!=NIL){ //compute the number of predecessors, and f
      numPred[i] = 0;
      adj_1 = G[i].adj_1;
      while (adj_1!=NULL){
        (numPred[i])++;
        if (f[adj_1->node]==NIL)
          f[adj_1->node] = i;
        else
          return true;
        adj_1 = adj_1->next;
      }
      //compute minSet
      if (numPred[i]==0){
        //it is added to minSet
        minSet[i] = mS;
        mS = i;
      } else{ //compute the cyclic part of the subgraph
        /*it belongs to the cycle/tree part of the subgraph depending
        on the next cycleVertices() call; temporarily is in the cycle part*/
        if (sGc!=NIL)
          prev[sGc] = i;
        next[i] = sGc;
        prev[i] = NIL;
        sGc = i;
      }
      i = G[i].nextInBlock;
    }
    B = Q[B].nextBlock;
  }
  /*here we know that we can apply PTB, since there are no multiple nodes;
  sGc points to the cyclic part of the subgraph (of the rank being analysed)
  f[i] stores adj of i that is composed only by one edge
  G[i].adj_1 stores adj_1 of i in the subgraph (since we divided the edges in
  initFBA).
  Moreover we compute the number of predecessor of each node and minSet
  to recognise the cycle nodes in the next cycleVertices() call*/
  C = X[C].nextXBlock;
  return false;
}
