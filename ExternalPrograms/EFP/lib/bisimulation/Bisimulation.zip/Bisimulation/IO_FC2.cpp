//------------------------------------------------------------------------------
//Title:       FC2 format interface
//Version:     1.1
//Author:      Thomas Dolso, Alberto Forti, Nadia Ugel(per quanto riguarda
//              l'input da file)
//Company:     Universit� degli Studi di Udine
//Description:
//------------------------------------------------------------------------------

#include <stdio.h>
#include <string.h>
#include "fastBisimulation.h"
#include "IO_FC2.h"

#define     MAX_bhtmp      400
#define     USED             1
#define     NOTUSED          0
#define     DELETED         -1
#define     DA_CANCELLARE   -2

automa *LoadFromFC2(char *fname)
{
/*
   Note :
   La particolare versione di FC2 considerata memorizza nella tabella dei behavs le sole
   etichette, mentre l'associazione con il particolare operatore (!,?,~,#,"") viene fatta
   al momento della definizione dell'arco (un esempio: '!2' operatore '!' associato
   all'etichetta definita dall'entry numero 2 della tabella.
   Per poter disettichettare il grafo e' necessario che gli operatori siano associati
   alle etichette direttamente nella tabella, in questo modo, al momento della definizione
   dell'arco, sara' presente solo un indice alla tabella. Lo stesso vale per operatori
   particolari quali 'tau', 'quit' e '-'.
   La forma della tabella sara' la seguente:
     tab[0] = "stato"    etichetta associata agli stati del grafo etichettato
     tab[1] = tau
     tab[2] = quit
     tab[3] = -
     tab[4] = !"etichetta numero 0 della tabella definita nel file"
     tab[5] = ?"etichetta numero 0 della tabella definita nel file"
     tab[6] = ~"etichetta numero 0 della tabella definita nel file"
     tab[7] = #"etichetta numero 0 della tabella definita nel file"
     tab[8] = epsilon"etichetta numero 0 della tabella definita nel file"
     tab[9] = !"etichetta numero 1 della tabella definita nel file"
     ecc... (std::cinque entrate per ogni entrate della tabella definita nel file)
   Questa tabella contiene tutte le possibilita' e molto probabilemente non tutte saranno
   utilizzate (solo dopo aver letto l'automa sapro' quali saranno utilizzate e quali no).
   Visto che l'algoritmo di minimizzazione non vuole 'buchi' in questa tabella
   sara' necessario compattarla.

    Dopo aver letto la tabella in questo modo si eseguono i seguenti passi:

      - lettura dell'automa e memorizzazione nella lista di adiacenza adeguando gli indici
        alle etichette della nuova tabella
      - compattamento della tabella
      - adeguamento indici alla tabella compattata
*/

  FILE *f;
  char s[400], c, c1, *p;
  indexType Nbehavs, Nvertex, Ne, Nbh, bhtabSize, *chkbh, mv, cdec, i, j, k, l;
  indexType tmp, bhtmp[MAX_bhtmp], *bhtmp1, totNe;
  int sSize;
  v_elem *Vertex;
  bhtab *behavs;
  automa *a;
  long CurrPos;

  /* Allocazione della struttura dati che conterra' la tabella dei behavs ed alcune
     informazioni associate */
  behavs = (bhtab *) malloc(sizeof(bhtab));

  /* Apertura del file FC2 */
  f = fopen(fname,"rb");
  if (f == NULL)
    error("File non trovato!");
  printf("File di input: %s\n",inputName);

  /* Prima fase: lettura della tabella dei behavs */
  /* Ora cerco il numero di elementi della tabella e lo memorizzo in Nbehavs */
  Nbehavs = -1;
  while (!feof(f)) {
    while ((c=fgetc(f)) == '%')
      while ((c=fgetc(f)) != '\n')
        ;
    ungetc(c,f);
    if (fscanf(f,"%s %d",&s,&i) == 2) {      // cerco "behavs n" o "B n" o "Bn" o "behavsn"
      if (strcmp(s,"behavs") == 0 || strcmp(s,"B") == 0) {
    	  Nbehavs = i;
        break;
      }
    }else if (s[0] == 'B'){
      Nbehavs = atoi(&s[1]);
      break;
    }else if (strncmp(s,"behavs",6) == 0){
      Nbehavs = atoi(&s[6]);
      break;
    }
  }
  if (Nbehavs == -1)
    error("Dimensione tabella dei behavs non trovata");

  /* Crea la tabella dei behavs */
  bhtabSize = (Nbehavs * 5) + 4;        // calcolo la dimensione
  behavs->bh = (char **) malloc(sizeof(bhtab) * bhtabSize);
  /* chkbh e' un array di supporto che ha lo stesso numero di entry della tabella dei behavs,
     servira' prima per compattare la tabella poi per rilocare gli indici dell'automa alle
     nuove posizioni della tabella compattata */
  chkbh = (indexType *) malloc(sizeof(indexType) * bhtabSize);

  /* Inizializza la tabella dei behavs e l'array ausiliario associato (chkbh[])*/
  for (i=0; i<bhtabSize; i++)
    chkbh[i]=0;
  behavs->bh[0] = "stato";
  behavs->bh[1] = "tau";
  behavs->bh[2] = "quit";
  behavs->bh[3] = "-";
  /* Leggo dal file i behavs e inizializzo il resto della tabella.
     L'indice 'i' segue la tabella del file, l'indice 'j' segue la tabella che sto
     inizializzando che ha quattro entrate per ogni entrata della tabella del file */
  for (i=0, j=4; i<Nbehavs; i++) {
    fscanf(f," %c%d",&c,&tmp);          // cerco ":n"
    if (c != ':')
      error("Errore nella definizione della tabella dei behaviours");
    fscanf(f," %s",s);                  // cerco la stringa dopo ":n"

    /* Per ogni behav letto dal file ne devo mettere quattro nella mia tabella,
       uno per ogni operatore (!,?,~,#) */
    sSize = strlen(s) + 2;
    /* etichetta: !s */
    p = behavs->bh[j] = (char *) malloc(sizeof(char) * sSize);
    strcpy(p+1,s);
    p[0] = '!';
    j++;
    /* etichetta: ?s */
    p = behavs->bh[j] = (char *) malloc(sizeof(char) * sSize);
    strcpy(p+1,s);
    p[0] = '?';
    j++;
    /* etichetta: ~s */
    p = behavs->bh[j] = (char *) malloc(sizeof(char) * sSize);
    strcpy(p+1,s);
    p[0] = '~';
    j++;
    /* etichetta: #s */
    p = behavs->bh[j] = (char *) malloc(sizeof(char) * sSize);
    strcpy(p+1,s);
    p[0] = '#';
    j++;
    /* etichetta: epsilon s */
    p = behavs->bh[j] = (char *) malloc(sizeof(char) * sSize);
    strcpy(p+1,s);
    p[0] = 'e';
    j++;

  }

  /* Seconda fase: lettura del grafo rappresentante l'automa */
  /* Cerco il numero di vertici e lo memorizzo in Nvertex.*/
  Nvertex = -1;
  while (!feof(f)) {
    if (fscanf(f,"%s %d",&s,&i) == 2) { // cerco "vertice n" o "V n" o "Vn" o "verticen"
      if (strcmp(s,"vertice") == 0 || strcmp(s,"V") == 0) {
        Nvertex = i;
        break;
      }
    }else if (s[0] == 'V'){
      Nvertex = atoi(&s[1]);
      break;
    }else if (strncmp(s,"vertice",7) == 0){
      Nvertex = atoi(&s[7]);
      break;
    }
  }
  if (Nvertex == -1)
    error("Numero vertici non trovato");

  /* Creazione e inizializzazione della lista di adiacenza */

  /* allocazione del vettore dei vertici */
  Vertex = (v_elem *) malloc(sizeof(v_elem) * Nvertex);
  if (Vertex == NULL)
    error("Errore di allocazione della memoria");
  // Ciclo sul numero di vertici
  for (i=0, totNe=0; i<Nvertex; i++) {
    // cerco "vn" o "vertexn", definizione dell'i-esimo vertice
    if (fscanf(f," %s",&s) == 1)  {
      if (strncmp(s,"vertex",6) == 0)
        tmp = atoi(&s[6]);
      else if (s[0] == 'v')
        tmp = atoi(&s[1]);
      else
        error("Errore: definizione di un vertice NON RICONOSCIUTA");
    }else
      error("Errore: definizione di un vertice NON RICONOSCIUTA");

    /* Salto il nome del vertice (se c'e') per andare a cercare il suo numero di archi*/
    fscanf(f," %s",&s);
    if (s[0]=='s' && s[1]=='\"'){
      if (s[strlen(s)-1] != '\"')
        while ((c=fgetc(f)) != '\"')
          ;
      fscanf(f," %s",&s);
    }else if (strncmp(s,"struct",6) == 0){
      c = fgetc(f);
      while (c != 'e' && c != 'E')
        c = fgetc(f);
      ungetc(c,f);
      fscanf(f," %s",&s);
    }

    //cerco "edges n", "E n", "En", "edgesn",
    Ne = -1;
    if (fscanf(f,"%d",&tmp) == 1){
      if (strcmp(s,"edges") == 0 || strcmp(s,"E") == 0)
        Ne = tmp;
    }else if (s[0] == 'E')
      Ne = atoi(&s[1]);
    else if (strncmp(s,"edges",5) == 0)
      Ne = atoi(&s[5]);
    if (Ne == -1)
      error("Errore: numero archi di un vertice NON RICONOSCIUTO");

    /* Mi assicuro che il numero di archi sia realmente Ne (questa fase e' necessaria per
       gestire i '+' all'interno delle etichette). Gli FC2 prodotti da fc2symbmin utilizzano
       questo tipo di definizione multipla di archi con etichette diverse ma con uguale
       vertice di arrivo. */
    CurrPos = ftell(f);
    do {
      c = fgetc(f);
      if (c == '+')
        Ne++;
    } while ((c != 'v') && (!feof(f)));
    fseek(f,CurrPos,0);

    /* Trovo e memorizzo gli archi del vertice corrente */
    // alcune inizializzazioni
    totNe += Ne;    //calcolo per informazione il numero totale di archi (o transizioni)
    Vertex[i].ne = Ne;    // numero di archi per questo vertice e' Ne

    /**********************************************************************************************************/
    //if (Ne != 0){
      Vertex[i].e = (e_elem *) malloc(sizeof(e_elem) * Ne);
      if (Vertex[i].e == NULL)
        error("Errore di allocazione della memoria");
    //}

    /* Lettura degli archi. 'j' e' l'indice dell'arco corrente. L'uso di questo indice
       e' un po' anomalo, 'j' viene incrementato da un ciclo 'do' interno. */
    for (j=-1; j<Ne-1;) {
      fscanf(f," %c",&c);       // mi posiziono all'inizio della def dell'arco
      if (c != 'b') {
        // Provo la versione (FC2MIN) di FC2
        fscanf(f,"%d %c",&tmp,&c);
        if (c != 'b')
          error("Errore nella definizione di un arco: non trovo 'b'");
      }
      /* Leggo le etichette associate a quest'arco.
         Nota: non conosco in anticipo quante etichette ci sono, quindi anziche' ripetere
         due volte questo ciclo, memorizzo in una struttura temporanea preallocata 'bhtmp[]',
         grande a sufficienza (si spera), gli indici alle etichette che leggo e man mano
         (usando la variabile 'k') le conto. bhtmp[] viene dimensionato al valore della
         costante MAX_bhtmp.
         Nota 2: puo' esserci solo un'etichetta di tau, quit e forse - */
      /* La variabile 'l' serve a contare gli archi definiti con '+'. Infatti nel caso
         di definizioni multiple non conosco subito il vertice di arrivo, grazie a 'l'
         sapro' quanti archi precedenti a quello corrente hanno lo stesso vertice
         di arrivo. */
      l = -1;
      do {    // questo 'do' cicla piu' di una volta solo se ci sono definizioni multiple
        j++;      // indice dell'arco corrente
        l++;      // conta gli archi con lo stesso vertice di arrivo
        k = 0;    // conta le etichette dell'arco corrente
        do {  // ciclo per determinare le etichette dell'arco corrente
          if (k == MAX_bhtmp)
            error("Errore: provare aumentando la costante MAX_bhtmp");
          if (fscanf(f,"%d %c",&tmp,&c1) != 0){
            //caso in cui c'e' epsilon i
            tmp = tmp * 5 + 4 + 4;
          }else if (fscanf(f," %c%d %c",&c,&tmp,&c1) != 3) {
            /* questa e' un'etichetta di tipo tau (t), quit (q) oppure - (-) */
	          tmp = 0;
            switch (c) {
	            case 't': fscanf(f,"%c%c",&c,&c1);  // salto "au" di tau
                        // mi posiziono sul prossimo carattere come dopo la lettura
                        // di un'etichetta normale
	                      fscanf(f," %c",&c1);
	                      tmp = 1;  // indice per tau sulla tabella dei behavs
                        break;
	            case 'q': error("Usato operatore 'quit'");
	            case '-': error("Usato operatore '-'");
              default : error("Errore nella ricerca dei behavs di un arco");
            }
          }
	        else {
            /* questa e' un'etichetta normale: operatore e indice */
	          tmp *= 5;  // adatto l'indice dell'etichetta alla tabella estesa
	          switch (c) {  // trovo l'entry giusta a seconda dell'operatore
              case '!': break;
	            case '?': tmp++; break;
	            case '~': tmp+=2; break;
              case '#': tmp+=3; break;
              default : error("Errore: operatore non riconosciuto");
            }
	          tmp+=4;  // salto i primi quattro indici della tabella
          }
	        bhtmp[k] = tmp;     // indice corretto alla nuova tabella
	        chkbh[tmp] = 1;     // marco come usata questa posizione della tabella
	        k++;
        /* Condizioni di uscita: '-' o 'r' : e' finito l'arco, la prossima cosa da cercare
                                             e' il vertice d'arrivo
                                       '+' : viene definito un altro arco e il vertice
                                             d'arrivo lo trovo dopo
        */
        } while( (c1 != '-') && (c1 != 'r') && (c1 != '+'));

        /* Ora so quante e quali etichette ha quest'arco quindi modifico la lista di adiacenza*/
        Vertex[i].e[j].nbh = k;       // numero di etichette
        Vertex[i].e[j].bh = (indexType*) malloc(sizeof(indexType) * k);
        if (Vertex[i].e[j].bh == NULL)
          error("Errore di allocazione della memoria");
        /* Salvo le etichette dall'array temporaneo nella lista di adiacenza */
        for (k--; k>=0; k--) Vertex[i].e[j].bh[k] = bhtmp[k];

      } while (c1 == '+');
      /* Ora definisco il vertice di arrivo per quest'arco e per tutti quelli che ho
         trovato nella definizione multipla, il loro numero e' in 'l'.
         L'if seguente e' per considerare piu' versioni di FC2, a seconda che il vertice
         d'arrivo sia definito con '->' oppure con 'r'. */
      if (c1 == '-') fscanf(f,"%c%d",&c,&tmp);         // cerco ">n"
      else fscanf(f," %d",&tmp);                       // cerco " n"
      /* Setto il vertice d'arrivo per l'arco corrente e per gli 'l' archi precedenti */
      do {
        Vertex[i].e[j-l].tv = tmp;
        l--;
      } while (l != -1);
    }
  }

  fclose(f);

  printf("\nAutoma originale: %d stati    e    %d transizioni\n",Nvertex,totNe);

  /* Conto le etichette iniziali delle azioni predefinite (tau,quit e -). Questo valore
     serve per agevolare alcune operazioni nel salvataggio dell'automa su FC2, libera
     dall'uso di inutili confronti tra stringhe. */
  behavs->ap = chkbh[1] + chkbh[2] + chkbh[3];

  /* Compattamento tabella dei behavs.
     A questo punto l'array chkbh[] contiene '1' nella posizioni 'i' se l'etichetta di
     indice 'i' e stata utilizzata, '0' altrimenti.
     Dopo il seguente ciclo 'for' l'array chkbh[] conterra' nella posizione 'i' il valore
     di quanto devo decrementare l'indice di etichetta 'i' per adattarlo alla tabella
     compattata. */
  mv = 1;           // prima posizione libera nella tabella compattata
  cdec = 0;         // decremento corrente
  for (i=1; i<bhtabSize; i++) {
    if (chkbh[i] == 0) cdec++;
    else {
      behavs->bh[mv] = behavs->bh[i];
      mv++;
      chkbh[i] = cdec;
    }
  }

  /* Aggiustamento indici nell'automa */
  for (i=0; i<Nvertex; i++) {
    Ne = Vertex[i].ne;
    for (j=0; j<Ne; j++) {
      Nbh = Vertex[i].e[j].nbh;     // Assegnazioni con l'unico scopo di migliorare la
      bhtmp1 = Vertex[i].e[j].bh;   // leggibilita' e in qualche modo l'efficienza
      for (k=0; k<Nbh; k++) bhtmp1[k] = bhtmp1[k] - chkbh[bhtmp1[k]];
    }
  }

  free(chkbh);      // chkbh[] non serve piu'

  behavs->n = mv;   // dimensione finale della tabella dei behavs

  a = (automa *) malloc(sizeof(automa));
  a->Nvertex = Nvertex;
  a->Nbehavs = mv;
  a->Vertex  = Vertex;
  a->behavs  = behavs;

  FillStructures(a); // Trasformazione in grafo con archi non etichettati e inizializzazione
                     // delle strutture dati usate dalle procedure di minimizzazione

  return(a);
}



void SaveToFC2(automa *a, char *FileName)
{
  indexType i, j, k, Nv, Ne, Nbh, v, Map, totNe;
  indexType *riloc, *tmpVertex, cdec, mv;
  FILE *f;
  v_elem *Vertex;
  e_elem *Edge;
  char **bh, *s, *EmptyString = "";

  GetMinimizedAutoma(a);  // Etichetta gli archi e segna quali stati dell'automa originale
                          // sono stati cancellati

  /* L'automa in input a questa procedura e' quello minimizzato nel quale possono esserci
     dei vertici cancellati (il cui campo 'ne' a valore 'DELETED').
     Eseguo compattamento dei vertici e scrittura su file degli stessi in due fasi separate
     perche' comunque bisogno di un ciclo, oltre a quello della scrittura, per determinare
     il numero di vertici, valore che deve essere scritto su file prima della definizione
     dei vertici. */
  /* Compattamento automa */
  // alcune inizializzazioni
  Nv = a->Nvertex;
  Vertex = a->Vertex;
  /* L'array tmpVertex conterra' i decrementi per i riferimenti ai vertici nel grafo
     compattato (come chkbh[] in LoadFromFC2). */
  tmpVertex = (indexType *) malloc(sizeof(indexType) * Nv);

  for (i=0, cdec = mv = 0; i<Nv; i++) {
    tmpVertex[i] = -1;
    if (Vertex[i].ne == DELETED) cdec++;
    else {
      Vertex[mv] = Vertex[i];
      mv++;
      tmpVertex[i] = cdec;
    }
  }
  Nv = mv;      // il nuovo numero di vertici e' mv
  a->Nvertex = Nv;

  /* Note:
     Prima di scrivere la tabella dei behavs su file devo separare gli operatori (!,?,~,#)
     dalle etichette, questo significa compattare la tabella perche' semplicemente
     togliendo quegli peratori otterrei voci duplicate, rilocare gli indici alla nuova
     tabella ottenuta. */

  /* Preparazione alla scrittura su file */
  if ((f = fopen(FileName,"wt")) == NULL)
    error("Errore aprendo il file in scrittura");
  // alcune inizializzazioni
  bh = a->behavs->bh;
  Nbh = a->behavs->n;
  Map = (a->behavs->ap) + 1;    // 'Map' contiene il numero di azioni usate (tau, quit o -)
                                // + 1 l'etichetta "stato" in posizione '0'
  /* L'array riloc servira' a rilocare gli indici alla tabella compatatta */
  riloc = (indexType *) malloc(sizeof(indexType) * a->behavs->n);
  if (riloc == NULL)
    error("Errore di allocazione della memoria (SaveFC2)");

  fprintf(f,"%% FC2 file (oc5 format)\n\nversion \"1\"\n\nnets 1\n\n");

  s = EmptyString;
  /* Elaborazione tabella dei behavs */
  /* Ora non conosco il numero di entry della tabella compattata quindi lo calcolo.
     Alla fine del 'for' l'array riloc[] conterra' in posizione 'i' la nuova posizione
     di un'etichetta 'i' nella tabella compattata. */
  for (i=Map, j=0; i<Nbh; i++) {
    if (strcmp(s,bh[i]+1) != 0) {
      s = bh[i]+1;
      j++;
    }
    riloc[i] = j-1;
  }

  fprintf(f,"h\"main\">0\nnet 0\nB %d\n",j);  // j e' la dimesione della tabella compattata

  s = EmptyString;
  /* Scrittura tabella */
  for (i=Map, j=0; i<Nbh; i++) {
    if (strcmp(s,bh[i]+1) != 0) {
      s = bh[i]+1;
      fprintf(f,":%d %s\n",j,s);
      j++;
    }
  }

  fprintf(f,"\nH 1\n:0 \"automaton\"\n\nL 1\n:0 \"initial\"\n\n");
  fprintf(f,"s\"...nome...\" l0>0 h0\n\nvertice %d\n\n",Nv);


  // Scrivo i vertici con i relativi archi
  for (i=0, totNe=0; i<Nv; i++) {
    Ne = Vertex[i].ne;
    Edge = Vertex[i].e;

    fprintf(f,"v%d s\"ST%d\" E%d\n",i,i,Ne);

    // Scrivo gli archi del vertice corrente
    totNe += Ne;        // calcolo per informazione il numero totale di archi
    for (j=0; j<Ne; j++) {
	  v = Edge[j].bh[0];
      /* Prima scrivo la prima etichetta poi le altre se ci sono. Separo i casi per
        scrivere correttamente e semplicemente il '.' che separa le etichette nel file. */
	  if (v<Map)
      fprintf(f,"   b %s",bh[v]);
      else fprintf(f,"   b %c%d",bh[v][0],riloc[v]);
	  for (k=1; k<Edge[j].nbh; k++) {
	    v = Edge[j].bh[k];
	    fprintf(f,".%c%d",bh[v][0],riloc[v]);
      }
	  v = Edge[j].tv;
	  fprintf(f,"\n   ->%d\n",(v-tmpVertex[v]));    // riloco e scrivo il vertice d'arrivo
                                                    // per quest'arco.
    }
  }

  fclose(f);
  printf("\nAutoma minimizzato: %d stati    e    %d transizioni",Nv,totNe);

  free(tmpVertex);
  free(riloc);
}




void DisposeAutoma(automa *a)
/* Rilascia la memoria allocata per l'automa */
{
  indexType i, j, Nv, Ne;
  v_elem *Vertex;

  Nv = a->Nvertex;
  Vertex = a->Vertex;

  for (i=0; i<Nv; i++) {
    Ne = Vertex[i].ne;
    for (j=0; j<Ne; j++) free(Vertex[i].e[j].bh);
    free(Vertex[i].e);
  }
  free(a);
}

void VisAutoma(automa *a)
{
  int i, j, k;
  v_elem *Vertex;
  bhtab *behavs;
  int Nvertex, Nbehavs;


  Nvertex = a->Nvertex;
  Nbehavs = a->Nbehavs;
  Vertex  = a->Vertex;
  behavs  = a->behavs;

  printf("Numero Vertici: %d\nNumero behavs: %d\n",Nvertex,Nbehavs);
  printf("\nTabella dei behavs\n");
  for (i=0; i<Nbehavs; i++) printf("%d: %s\n",i,behavs->bh[i]);

  printf("\n Vertici e relativi archi\n");
  for (i=0; i<Nvertex; i++) {
    printf("\nNe[%d] = %d\n",i,Vertex[i].ne);
    for (j=0; j<Vertex[i].ne; j++) {
      for (k=0; k<Vertex[i].e[j].nbh; k++) printf("%d.",Vertex[i].e[j].bh[k]);
      printf(" ->%d\n",Vertex[i].e[j].tv);
    }
  }
}

void error(char *s)
{
  printf("\n\n%s\n\n",s);
  exit(1);
}


void FillStructures( automa *A )
{
/*
    Questa funzione si occupa della trasformazione di un automa con i soli archi etichettati
    in uno con i soli stati etichettati e dell'inizializzazione delle strutture dati X e Q
    che vengono utilizzate dalle procedure che eseguono gli algoritmi di PaigeTarjan e di
    FastBisimulation.
    La chiamata a "fill_structures" verra' effettuata alla fine di "LoadFromFC2", che
    memorizza in una struttura dati di tipo "automa" il grafo rappresentato all'interno del
    file .FC2 passatogli come input. Tale struttura dati verra' passata come argomento a
    "fill_structure" che la analizzera' e creera' un grafo equivalente con i soli stati
    etichettati. La struttura dati in cui tale automa viene memorizzato e' G, anch'essa
    utilizzata dalle procedure che implementano PaigeTarjan e FastBisimulation.

    INPUT:      A, l'automa con soli archi etichettati che dev'essere convertito

    OUTPUT:     nessuno (Gli array X, Q e G sono globali, quindi non e' stato necessario
                ritornare alcunche' come output)
*/

    // Variabili
    indexType i ;

    // Inizializzazione della struttura dati X. Tale struttura dati avra' dimensione iniziale
    // pari al numero totale di etichette presenti nell'automa. Ogni elemento dell'array X ha
    // un "puntatore" all'elemento precedente ed uno a quello successivo. L'elemento di indice
    // 0 non avra' alcun elemento precedente e cio' verra' indicato dal valore NIL, cosi' come
    // l'elemento di indice "A->Nbehavs" non avra' alcun elemento successivo.
    // Il campo "firstBlock" viene qui inizializzato a NIL, ma verra' riconsiderato e aggiornato
    // correttamente dalla funzione "setpointers".

    // Inizializzazione del primo e dell'ultimo blocco di X
    X[0].prevXBlock = NIL ;
    X[0].nextXBlock = 1 ;
    X[0].firstBlock = NIL ;
    X[A->Nbehavs - 1].prevXBlock = A->Nbehavs - 2 ;
    X[A->Nbehavs - 1].nextXBlock = NIL ;
    X[A->Nbehavs - 1].firstBlock = NIL ;

    // Inizializzazione dei restanti blocchi di X
    for ( i=1 ; i<(A->Nbehavs - 1) ; i++ )
    {
        X[i].nextXBlock = i+1 ;
        X[i].prevXBlock = i-1 ;
        X[i].firstBlock = NIL ;
    } ;

    // Questa funzione si occupa effettivamente della conversione del grafo "A", con i soli
    // archi etichettati, in uno con i soli stati etichettati. Inoltre assegna ad ogni stato
    // l'elemento di X che rappresenta la sua etichetta (per i dettagli si vedano le spiegazioni
    // delle funzioni "createG" e "setpointers")
    CreateG( A->Nvertex, A->Vertex ) ;

    // Gestione dei puntatori tra le strutture dati G ed X
    SetPointers( A->Nbehavs ) ;

    // Procedura che inizializza i restanti campi di G (quelli non inizializzati dalle precedenti
    // funzioni) e quelli di Q
}




void CreateG( int num_v, v_elem *Gtemp )
{
/*
    Questa funzione si occupa effettivamente della conversione del grafo con soli archi
    etichettati, passatogli come input, in uno con soli stati etichettati.
    Stabilisce inoltre, per ogni stato, a quale blocco esso appartenga (per blocco si intende
    un elemento dell'array X, che rappresenta in modo univoco una etichetta del grafo). In altre
    parole, all'inizio, tutti gli stati con uguale etichetta apparterranno ad uno stesso blocco.
    L'array X ha dimensione pari al numero totale delle etichette.

    INPUT:      num_v, il numero di vertici del grafo Gtemp
                Gtemp, il grafo con i soli archi etichettati

    OUTPUT:     nessuno (L'array G e' globale, quindi non e' stato necessario ritornare
                alcunche' come output)
*/

    // Variabili
    indexType v, e, b ;
    struct adjList **curr_adj ;

    // Creo "num_v" vertici in G. Questi sono gli stati presenti anche nel grafo con soli archi
    // etichettati Gtemp e che, per convenzione implementativa, avranno tutti etichetta 0 (in
    // realta' la loro etichetta potrebbe assumere un qualunque valore). Tutti questi stati
    // apparterranno quindi, come si puo' notare dall'assegnamento "G[v].block = 0", al blocco
    // 0, ovvero all'elemento dell'array X di indice 0.
    for ( v=0 ; v<num_v ; v++ )
    {
        G[v].block = 0 ;
        G[v].label = 0 ;
    }

    // La variabile "numberOfNodes" e' globale e indica il numero totale di stati del grafo su
    // cui verranno eseguiti gli algorimi di PaigeTarjan e FastBisimulation. A questo punto sono
    // stati creati "num_v" stati, pari al numero totale di stati del grafo con i soli archi
    // etichettati; il suo valore iniziale sara' quindi "num_v" e crescera' man mano che gli archi
    // vengono disetichettati.
    numberOfNodes = num_v ;

    // Creo tutti gli altri stati (disetichettando gli archi). Per ogni stato del grafo di partenza
    // Gtemp, scandisco la sua lista di adiacenza. I casi che si possono presentare sono i seguenti:
    // 1. un arco con un'unica etichetta
    // 2. un arco con piu' etichette
    // Nel primo caso, "spezzo" in due l'arco ed inserisco tra i due uno stato con etichetta uguale
    // a quella posseduta dall'arco "spezzato". Nel secondo caso, supponendo che l'arco abbia "n"
    // etichette, creero' "n" stati, ognuno dei quali avra' una delle etichette possedute dall'arco.
    // Tali stati manterranno l'ordine in cui le etichette sono memorizzate sull'arco, nel senso che
    // se l'etichetta "i" precedeva l'etichetta "j" sull'arco, vi sara' un arco dallo stato con
    // etichetta "i" verso quello con etichetta "j". Ovviamente il primo degli "n" stati avra' un
    // arco entrante proveniente dallo stato "v" che stiamo considerando, mentre l'ultimo degli "n"
    // stati, avra' un arco uscente verso lo stato in cui giungeva l'arco che stiamo "spezzando".
    for ( v=0 ; v<num_v ; v++ )
    {
        // Puntatore alla lista di adiacenza dello stato corrente, che verra' creata dalle seguenti
        // linee di codice
        curr_adj = &(G[v].adj) ;

        // Ciclo che considera tutti gli archi uscenti da "v"
        for ( e=0 ; e<Gtemp[v].ne ; e++ )
        {
            // Creo un nuovo stato (il primo nella catena di etichette). Come detto precedentemente
            // il campo "block" viene qui inizializzato con l'indice dell'elemento di X che rappresenta 
            // l'etichetta dello stato che stiamo creando
            G[numberOfNodes].block = Gtemp[v].e[e].bh[0] ;
            G[numberOfNodes].label = Gtemp[v].e[e].bh[0] ;
            numberOfNodes ++ ;

            // Aggiornamento della lista di adiacenza di v. Viene aggiunto un nuovo elemento nella
            // lista di adiacenza di v, ovvero un nuovo arco che raggiunge lo stato appenza creato
            *curr_adj = new struct adjList ;
            (*curr_adj)->node = numberOfNodes - 1 ;
            (*curr_adj)->next = NULL ;
            curr_adj = &((*curr_adj)->next) ;

            // Creo gli stati dal secondo in poi nella catena delle etichette. Questo ciclo viene
            // eseguito solamente nel caso in cui l'arco che stiamo considerando possegga piu' di
            // una etichetta
            for ( b=1 ; b<Gtemp[v].e[e].nbh ; b++ )
            {
                // Creo un nuovo stato
                G[numberOfNodes].block = Gtemp[v].e[e].bh[b] ;
                G[numberOfNodes].label = Gtemp[v].e[e].bh[b] ;

                // Aggiorno la lista di adiacenza dello stato precedentemente creato, ovvero aggiungo
                // un arco dal penultimo stato che abbiamo creato a quello appena creato
                G[numberOfNodes - 1].adj = new struct adjList ;
                G[numberOfNodes - 1].adj->node = numberOfNodes ;
                G[numberOfNodes - 1].adj->next = NULL ;

                numberOfNodes ++ ;
            }

            // Aggiornamento della lista di adiacenza dell'ultimo stato che abbiamo creato
            G[numberOfNodes - 1].adj = new struct adjList ;
            G[numberOfNodes - 1].adj->node = Gtemp[v].e[e].tv ;
            G[numberOfNodes - 1].adj->next = NULL ;
        }
    }
}




void SetPointers( int n )
{
/*
    Questa funzione gestisce i puntatori tra l'array X e l'array G nel seguente modo:
    si e' detto che l'array X ha dimesione pari al numero totale di etichette presenti nel grafo.
    Ogni elemento di questo array rappresenta quindi una classe di stati, ovvero tutti quelli che
    hanno come etichetta quella di cui tale elemento e' il rappresentante (quindi tutti gli stati
    con uguale etichetta avranno lo stesso campo "block"). Inoltre, ogni elemento dell'array X
    possiede uno stato rappresentante (indicato dal campo "firstBlock" di X) ed ogni stato avra'
    due "puntatori" al precedente ed al successivo elemento nel blocco. Cosicche', dato un
    qualunque elemento (blocco) di X, guardando il campo "firstBlock" e seguendo i puntatori agli
    elementi precedente e successivo, e' possibile individuare tutti gli stati appartenenti a tale
    blocco.

    INPUT:      n, il numero totale di etichette

    OUTPUT:     nessuno (G ed X sono globali)
*/

    // Variabili
    indexType *curr_node, i, x ;

    // Allocazione dell'array temporaneo utilizzato dal ciclo seguente
    curr_node = new int[n] ;

    //
    for ( i=0 ; i<numberOfNodes ; i++ )
    {
        // Prelevo il blocco a cui appartiene lo stato "i"
        x = G[i].block ;

        // Se tale blocco non ha ancora un rappresentante (il campo "firstBlock" e' uguale a NIL)
        // allora lo stato "i" diventa il suo rappresentante. Ovvero scelgo come rappresentante di
        // un blocco che rappresenta l'etichetta "k", il primo stato che trovo che abbia etichetta "k"
        if ( X[x].firstBlock == NIL )
        {
            X[x].firstBlock = i ;
            G[i].prevInBlock = NIL ;
        		G[i].nextInBlock = NIL ;
        }

        // Se invece tale blocco "x" ha gia' un rappresentante, lego lo stato i, attraverso i puntatori
        // "prevInBlock" e "nextInBlock" all'ultimo elemento che ho trovato con uguale etichetta.
        // L'array "curr_node" viene appunto usato per tenere traccia di quale sia l'ultimo stato che
        // ho trovato, per ogni etichetta (curr_node ha dimensione pari al numero totale di etichette)
        else
        {
            G[i].prevInBlock = curr_node[x] ;
            G[i].nextInBlock = NIL ;
            G[curr_node[x]].nextInBlock = i ;
        } ;

        // Aggiorno l'array temporaneo
        curr_node[x] = i ;
    } ;

    // Deallocazione dell'array temporaneo
    delete[] curr_node;
}

void GetMinimizedAutoma( automa *A )
{
/*
    Questa funzione crea, a partire dal grafo minimizzato (con soli stati etichettati) memorizzato
    in G e dal grafo iniziale A (con soli archi etichettati) passato come input, il grafo minimizzato
    con soli archi etichettati, che verra' salvato su un file .FC2 dalla funzione "SaveToFC2"

    INPUT:      A, l'automa di partenza con i soli archi etichettati

    OUTPUT:     nessuno
*/

    // Con questa funzione vengono indicati gli stati che gli algoritmi di PaigeTarjan e
    // FastBisimulation hanno eliminato (in realta' tali algoritmi non operano tale eliminazione,
    // che viene effettivamente compiuta dalle funzioni "DeleteNodes" e "SaveToFC2")
    MarkDeletedNodes() ;

    // Viene effettuata la vera e propria eliminazione degli stati marcati com "DA_CANCELLARE" dalla
    // funzione "MarkDeletedNodes"
    DeleteNodes( A ) ;
}




void MarkDeletedNodes()
{
/*
    MarkDeletedNodes non fa altro che marcare gli stati che devono essere cancellati, valutando
    il valore che alcuni campi degli array G e Q assumono al termine della computazione delle
    funzioni che implementano gli algoritmi di PaigeTarjan e FastBisimulation. Tali stati vengono
    effettivamente eliminati dalle funzioni "DeleteNodes" e "SaveToFC2".

    Nota: le implementazioni degli algoritmi di minimizzazione qui proposte sono distruttive
          rispetto agli array Q ed X, pertanto l'unico modo per sapere quali stati sono bisimili
          tra loro, e' controllare il campo "block" di tali stati, che indica dunque il blocco
          cui essi appartengono.

    INPUT:      nessuno

    OUTPUT:     nessuno
*/

    // Variabili
    indexType i, q ;

    // Al termine delle funzioni di minimizzazione, alcuni campi di Q non servono piu' e vengono
    // qui riutilizzati per altri scopi. Il primo ad essere preso in considerazione e' il campo "size"
    // che viene usato per tenere traccia del fatto che un blocco di Q abbia o meno uno stato
    // rappresentante (un elemento (blocco) di Q rappresenta un insieme di stati bisimili)
    // Inizializzazione del campo "size" a NOTUSED, per indicare che nessun elemento (blocco) di Q ha
    // ancora il proprio stato rappresentante
    for ( i=0 ; i<QBlockLimit ; i++ )            //il max di Q puo' essere superiore a nON *****************************************
        Q[i].size = NOTUSED ;

    // Annoto gli stati che devono essere cancellati
    for ( i=0 ; i<numberOfNodes ; i++ )
    {
        // Considero il blocco cui appartiene lo stato "i"
        q = G[i].block ;

        // Se tale blocco non ha ancora un rappresentante (il campo "size" e' uguale a NOTUSED)
        // allora lo stato "i" diventa il suo rappresentante. Ovvero scelgo come rappresentante di
        // un blocco "k", il primo stato che trovo che abbia il campo "block" con valore "k"
        if ( Q[q].size == NOTUSED )
        {
            Q[q].size = USED ;
            Q[q].firstNode = i ;
        }

        // Altrimenti indico che tale stato dev'essere cancellato, in quanto bisimile allo stato
        // rappresentante del blocco cui esso appartiene. Utilizzo il campo "nextInBlock" in quanto
        // non sara' piu' utilizzato da alcuna funzione
        else
            G[i].nextInBlock = DA_CANCELLARE ;
    }
}





void DeleteNodes( automa *A )
{
/*
    DeleteNodes si occupa di indicare quali tra gli stati del grafo di partenza A, passato come input,
    devono essere cancellati, considerando il campo "nextInBlock" degli elementi dell'array G, modificato
    dalla funzione "MarkDeletedNodes".
    L'automa A che viene modificato da questa funzione verra' successivamente passato come input alla
    funzione "SaveToFC2" che capira' quali stati e quali archi debbano essere memorizzati nel file .FC2
    che produrra' come output.

    INPUT:      A, l'automa di partenza, con i soli archi etichettati

    OUTPUT:     nessuno
*/

    // Variabili
    indexType i, j ;

    // Segno nell'automa A di partenza quali tra i suoi stati sono stati indicati come "DA_CANCELLARE"
    // dalla funzione "MarkDeletedNodes"
    for ( i=0 ; i<A->Nvertex ; i++ )
    {
        // Se lo stato "i" dev'essere cancellato, ovvero se la funzione "MarkDeletedNodes" ha impostato
        // il suo campo "nextInBlock" a "DA_CANCELLARE", allora indico in A che tale nodo dev'essere
        // cancellato. Utilizzo il campo "ne" di "A->Vertex", che indica il numero di archi uscenti, in
        // quanto, visto che tale stato verra' cancellato, esso non servira' piu'
        if ( G[i].nextInBlock == DA_CANCELLARE )
            A->Vertex[i].ne = DELETED ;

        // Se invece tale stato dev'essere conservato, modifico gli archi (se necessario) come segue
        else
        {
            for ( j=0 ; j<A->Vertex[i].ne ; j++ )
            {
                // Modifica degli archi: se un nodo di quelli che non devono essere cancellati ha un
                // arco uscente che giunge ad un nodo marcato come "DA_CANCELLARE", faccio puntare
                // l'arco verso il nodo rappresentante del blocco a cui tale nodo da cancellare appartiene.
                // Utilizzo il campo "tv" di "A->Vertex[].e[]", che indica lo stato a cui punta l'arco
                // considerato, in quanto non servira' piu'
                if ( G[ A->Vertex[i].e[j].tv ].nextInBlock == DA_CANCELLARE )
                    A->Vertex[i].e[j].tv = Q[ G[A->Vertex[i].e[j].tv].block ].firstNode ;
            }
        }
    }
}
